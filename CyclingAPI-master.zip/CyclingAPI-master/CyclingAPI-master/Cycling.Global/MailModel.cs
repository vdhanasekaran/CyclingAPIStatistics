﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Cycling.Global
{
    public class MailModel
    {
        [Required]
        public string Sender { get; set; }
        [Required]
        public string Recipient { get; set; }
        public string RecipientCC { get; set; }
        public string RecipientBCC { get; set; }
        [Required]
        public string Subject { get; set; }
        [Required]
        public string Body { get; set; }

        public string AttachmentFile { get; set; }

        [Required]
        public string Host { get; set; }
        public int Port { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public bool SSL { get; set; }


    }
}
