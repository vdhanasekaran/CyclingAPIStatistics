﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Text;

namespace Cycling.Global
{
    public class MailHelper : IMailHelper
    {
        public MailHelper()
        {

        }
        public bool SendEmail(MailModel model)
        {
            try
            {
                Attachment att = null;

                var message = new MailMessage(model.Sender, model.Recipient, model.Subject, model.Body);

                if (!string.IsNullOrEmpty(model.RecipientCC))
                {
                    message.CC.Add(model.RecipientCC);
                }
                if (!string.IsNullOrEmpty(model.RecipientBCC))
                {
                    message.Bcc.Add(model.RecipientBCC);
                }

                if (model.Recipient.Split(';').Length > 1)
                {
                    message.To.RemoveAt(0);
                    foreach (var address in model.Recipient.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        message.To.Add(address);
                    }

                }

                message.IsBodyHtml = true;

                var smtp = new SmtpClient(model.Host, model.Port);

                if (model.Port == 587)
                {
                    model.SSL = true;
                }

                if (!string.IsNullOrEmpty(model.AttachmentFile))
                {
                    if (File.Exists(model.AttachmentFile))
                    {
                        att = new Attachment(model.AttachmentFile);
                        message.Attachments.Add(att);
                    }
                }

                if (!string.IsNullOrEmpty(model.Username) && !string.IsNullOrEmpty(model.Password))
                {
                    //smtp.UseDefaultCredentials = false;
                    smtp.Credentials = new NetworkCredential(model.Username, model.Password);
                }

                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.EnableSsl = model.SSL;
                smtp.Send(message);
                message.Dispose();
                smtp.Dispose();
                return true;
            }
            catch (Exception ex)
            {
                string errorMsg = ex.Message.ToString();
                throw ex;
                //return false;
            }


        }
    }
}
