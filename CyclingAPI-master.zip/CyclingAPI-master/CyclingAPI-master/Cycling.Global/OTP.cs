﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Net.Http;
using System.Text;

namespace Cycling.Global
{
   public class OTP
    {

        private  IConfiguration configuration = null;
        public OTP(IConfiguration configuration )
        {
            this.configuration = configuration;
           // AuthyAPIKey = ConfigurationManager.AppSettings["OTPAPIKey"];
        }
       
        public static bool Verification(int OTPNumber,int UserID)
        {
            bool isVerified = false;
            
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("X-Authy-API-Key", AuthyAPIKey);

                var authy_id = UserID;
                var token = OTPNumber;

                HttpResponseMessage response = client.GetAsync(
                    $"https://api.authy.com/protected/json/verify/{token}/{authy_id}").Result;

              
                    if (response.IsSuccessStatusCode == true)
                    {
                        HttpContent responseContent = response.Content;
                        var obj = JObject.Parse(responseContent.ReadAsStringAsync().Result);
                        string Token  = Convert.ToString(obj["token"]);
                        isVerified = Token == "is valid" ? true : false;
                    }
                    
                  return isVerified;
               
            }
        }

        public static bool SendOTP(int UserID) 
        {
            bool OTPSent = false;
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("X-Authy-API-Key", AuthyAPIKey);

                var authy_id = UserID;

                HttpResponseMessage response = client.GetAsync(
                    $"https://api.authy.com/protected/json/sms/{authy_id}").Result;

                if (response.IsSuccessStatusCode == true)
                {
                    OTPSent = true;
                }
                return OTPSent;
            }

        }
        public static int UserCreate(string PhoneNumber,string EmailID)
        {
            int UserID = 0;

            string MobileNo = PhoneNumber.Trim().Substring(PhoneNumber.LastIndexOfAny(" ".ToCharArray()));
            string CountryCode = PhoneNumber.Trim().Substring(0,PhoneNumber.LastIndexOfAny(" ".ToCharArray()));

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("X-Authy-API-Key", AuthyAPIKey);
                var MobileNumber = PhoneNumber.Split(" ").ToString();
                var requestContent = new FormUrlEncodedContent(new[] {
                new KeyValuePair<string, string>("user[email]", EmailID),
                new KeyValuePair<string, string>("user[cellphone]", MobileNo),
                new KeyValuePair<string, string>("user[country_code]",CountryCode),
            });

                HttpResponseMessage response = client.PostAsync(
                    "https://api.authy.com/protected/json/users/new",
                    requestContent).Result;
                if(response.IsSuccessStatusCode == true)
                {
                    HttpContent responseContent = response.Content;
                    var obj = JObject.Parse(responseContent.ReadAsStringAsync().Result);
                    UserID = Convert.ToInt32(obj["user"]["id"]);
                }
                return UserID;
            }
        }

        private const string AuthyAPIKey = "E30FlvQRld0QrvxOjFMFzYyuVyEWdR76";

    }

}
