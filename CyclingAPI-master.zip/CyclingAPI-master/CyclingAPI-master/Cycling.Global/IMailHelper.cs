﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Global
{
   public interface IMailHelper
    {
        bool SendEmail(MailModel model);
    }
}
