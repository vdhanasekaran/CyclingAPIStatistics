﻿using System;

namespace Cycling.Global
{
    public class Class1
    {
    }
}
