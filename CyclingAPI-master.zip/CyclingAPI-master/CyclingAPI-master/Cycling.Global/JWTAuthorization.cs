﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Net.Http;
using System.Net;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.Filters;
using IAuthorizationFilter = Microsoft.AspNetCore.Mvc.Filters.IAuthorizationFilter;

using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Hosting;

namespace Cycling.Global
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
    public class JWTAuthorization : Attribute, IAuthorizationFilter
    {
        protected JsonSerializerSettings JsonSettings { get; private set; }
        private short Unauthorized_Code = (short)HttpStatusCode.Unauthorized;
        
        public JWTAuthorization()
        {
            
            //JsonSettings = new JsonSerializerSettings()
            //{
            //    Formatting = Formatting.Indented
            //};
           

        }


        public void OnAuthorization(AuthorizationFilterContext context)
        {
            try
            {
                
                    var _Token = context.HttpContext.Request.Headers.SingleOrDefault(x => x.Key == "Authorization");
                    var _Services = context.HttpContext.RequestServices;
                    IConfiguration _configuration = (IConfiguration)_Services.GetService(typeof(IConfiguration));

                    if (_Token.Key != null)
                    {
                        string TokenString = _Token.Value.SingleOrDefault();
                        JWT_TokenHandler JWT_TokenHandlerObj = new JWT_TokenHandler(_configuration);
                        if (!JWT_TokenHandlerObj.Validate_Token(TokenString))
                        {
                            context.HttpContext.Response.StatusCode = Unauthorized_Code;
                            context.Result = new JsonResult(new { status = "Unauthorized", Error = "Invalid Token" });
                        }

                        return;
                    }

                    context.HttpContext.Response.StatusCode = Unauthorized_Code;
                    context.Result = new JsonResult(new { status = "Unauthorized" });
                    return;
            
            }
            catch (Exception ex)
            {
                context.HttpContext.Response.StatusCode = Unauthorized_Code;
                context.Result = new JsonResult(new { status = "Unauthorized", Error = ex.Message });
            }
        }
    }
}
