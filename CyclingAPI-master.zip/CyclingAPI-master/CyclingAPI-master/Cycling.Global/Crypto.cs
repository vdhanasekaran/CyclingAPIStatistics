﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace Cycling.Global
{
   public class Crypto
    {
		Crypto()
		{

		}

		#region ENCRYPTION / DECRYPTION FUNCTIONS

		public static string DoEncrypt(string strOriginal)
		{
			try
			{
				MemoryStream objMS = new MemoryStream();
				Byte[] clearBytes = new UTF8Encoding().GetBytes(strOriginal);
				Byte[] iv = { 2, 63, 9, 36, 235, 174, 78, 12 };
				Byte[] Key = Convert.FromBase64String(CryptoKey);

				DESCryptoServiceProvider objDES = new DESCryptoServiceProvider();
				objDES.IV = iv;
				objDES.Key = Key;
				objDES.Mode = CipherMode.ECB;
				objDES.Padding = PaddingMode.PKCS7;

				ICryptoTransform objCryptTransform = objDES.CreateEncryptor(objDES.Key, objDES.IV);
				CryptoStream objCryptStream = new CryptoStream(objMS, objCryptTransform, CryptoStreamMode.Write);
				objCryptStream.Write(clearBytes, 0, clearBytes.Length);
				objCryptStream.Close();
				string strEncryptedValue = Convert.ToBase64String(objMS.ToArray());
				objMS.Close();
				objDES.Clear();
				return strEncryptedValue;

			}
			catch (Exception objError)
			{
				throw new Exception("Error while performing encryption.", objError);
			}
		}

		public static string DoDecrypt(string strEncrypted)
		{

			try
			{
				MemoryStream objMS = new MemoryStream(Convert.FromBase64String(strEncrypted));
				Byte[] iv = { 2, 63, 9, 36, 235, 174, 78, 12 };
				Byte[] Key = Convert.FromBase64String(CryptoKey);
				DESCryptoServiceProvider objDES = new DESCryptoServiceProvider();
				objDES.IV = iv;
				objDES.Key = Key;
				objDES.Mode = CipherMode.ECB;
				objDES.Padding = PaddingMode.PKCS7;
				ICryptoTransform objCryptTransform = objDES.CreateDecryptor(objDES.Key, objDES.IV);
				CryptoStream objCryptStream = new CryptoStream(objMS, objCryptTransform, CryptoStreamMode.Read);

				StreamReader objSR = new StreamReader(objCryptStream, true);
				string strOriginalValue = objSR.ReadToEnd(); ;

				objSR.Close();
				objMS.Close();
				objCryptStream.Close();
				objDES.Clear();
				return strOriginalValue;

			}
			catch (Exception objError)
			{
				throw new Exception("Error while performing encryption.", objError);
			}
		}


		#region KEY <---------> KEY
		private const string CryptoKey = "hkBopNxR/p0=";
		#endregion KEY <--------->KEY

		#endregion

	}
}
