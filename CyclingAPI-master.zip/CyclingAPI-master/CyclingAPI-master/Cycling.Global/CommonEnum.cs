﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Global
{
   public class CommonEnum
    {
        public enum FileCategory
        {
            Certificate = 1,
            DeadLineCertificate = 2,
            TetanusProphylctis = 3
        }
    }
}
