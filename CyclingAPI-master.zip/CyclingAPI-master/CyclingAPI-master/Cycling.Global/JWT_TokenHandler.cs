﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
namespace Cycling.Global
{
    public class JWT_TokenHandler: IJWT_TokenHandler
    {

        private readonly RequestDelegate _next;
        private IConfiguration _configuration = null;
       

        public JWT_TokenHandler(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        
        public JWT_TokenHandler(RequestDelegate next, IConfiguration configuration  )
        {
            _configuration = configuration;
            _next = next;
        
        }

        public async Task InvokeAsync(HttpContext httpContext)
        {
            try
            {
               
                    Validate_JWT_Token(httpContext);
                    await _next(httpContext);
           
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private bool Validate_JWT_Token(HttpContext httpContext)
        {
            string TokenString = httpContext.Request.Headers["Authorization"];
            return Validate_Token(TokenString);
        }

        public bool Validate_Token(String TokenString)
        {
            bool result = false;
            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                var validationParameters = GetValidationParameters();

                if (!string.IsNullOrEmpty(TokenString))
                {
                    if (TokenString.ToLower().Contains("bearer"))
                    {
                        int lastindexOfSpace = TokenString.LastIndexOf(" ") + 1;
                        TokenString = TokenString.Substring(lastindexOfSpace);
                    }
                    SecurityToken validatedToken = new JwtSecurityToken(TokenString);
                    IPrincipal principal = tokenHandler.ValidateToken(TokenString, validationParameters, out validatedToken);
                    result = true;
                }
                else
                {
                    throw new Exception("JWT token is missing.");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;

        }

        private TokenValidationParameters GetValidationParameters()
        {

            if (_configuration == null)
            {
                throw new Exception("Configuration is null.");
            }

            if (String.IsNullOrEmpty(_configuration["JwtIssuer"]))
            {
                throw new Exception("JwtIssuer is null or empty.");
            }

            if (String.IsNullOrEmpty(_configuration["JwtKey"]))
            {
                throw new Exception("JwtKey is null or empty.");
            }

            return new TokenValidationParameters()
            {
                LifetimeValidator = (before, expires, token, parameters) =>
                {
                    if (expires != null && expires.Value.ToLocalTime() < DateTime.Now)
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                },
                ValidateLifetime = true,
                ValidateAudience = true,
                ValidateIssuer = true,
                ValidIssuer = _configuration["JwtIssuer"],
                ValidAudience = _configuration["JwtIssuer"],
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtKey"])) // The same key as the one that generate the token
            };
        }
        public  string GenerateJSONWebToken(string UserName , long CompanyID)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtKey"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            List<Claim> ClaimList = new List<Claim>();
            Claim ClaimObj1 = new Claim("UserName", UserName); 
            Claim ClaimObj2 = new Claim("CompanyID", CompanyID == 0 ? null:Convert.ToString(CompanyID));
            ClaimList.Add(ClaimObj1);
            ClaimList.Add(ClaimObj2);
            var token = new JwtSecurityToken(_configuration["JwtIssuer"],
             _configuration["JwtIssuer"],
              ClaimList,
              signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

    }

    public static class JWTMiddlewareExtension
    {
        public static IApplicationBuilder UseJWTTokenAuthentication(
            this IApplicationBuilder builder, IConfiguration configuration)
        {
            return builder.UseMiddleware<JWT_TokenHandler>(configuration);
        }
    }
}

