﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Global
{
   public interface IJWT_TokenHandler 
    {
        string GenerateJSONWebToken(string UserName, long CompanyID);


    }
}
