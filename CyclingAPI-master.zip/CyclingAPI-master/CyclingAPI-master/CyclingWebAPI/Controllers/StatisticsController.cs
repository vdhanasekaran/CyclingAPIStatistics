﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cycling.Service.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CyclingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StatisticsController : ControllerBase
    {
        private readonly IStatisticsService _IStatisticsService;
       public StatisticsController(IStatisticsService _IStatisticsService)
        {
            this._IStatisticsService = _IStatisticsService;
        }
        // GET: api/Statistics/GetRaceData/5
        [HttpGet("GetRaceData/{UserID}")]
        public IActionResult SelectRaceData(Guid UserID)
        {
            var Data = _IStatisticsService.SelectRacedata(UserID);
            if(Data == null)
            {
                return new JsonResult(NotFound());
            }
            else
            {
                return new JsonResult(Data); ;
            }
        }

        [HttpGet("HeartRate/{userId}")]
        public IActionResult GetHeartRateDetails(Guid userId)
        {
            return Ok(_IStatisticsService.GetHeartRateDetails(userId));
        }
    }
}
