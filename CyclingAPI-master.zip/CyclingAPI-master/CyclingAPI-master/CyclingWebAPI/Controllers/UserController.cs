﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Cycling.Model.Model.Snapshot;
using Cycling.Service.Interfaces;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using static Cycling.Global.CommonEnum;

namespace CyclingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _IUserService;
        private readonly IHostingEnvironment hostingEnvironment;
       public UserController(IUserService _IUserService, IHostingEnvironment hostingEnvironment)
        {
            this._IUserService = _IUserService;
            this.hostingEnvironment = hostingEnvironment;
        }

        [HttpPost("UserRegistration")]
        public IActionResult SignUp(UserSnapshot Model)
        {
            try
            {  
                if (!_IUserService.EmailAleadyExists(Model.Email))
                {
                    var User = _IUserService.SignUp(Model);
                    return new JsonResult(Model);
                }
             else
                {
                    return BadRequest("Email ID already exists");
                }
            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
           
        }

        [HttpPost("ProfileUpdate")]
        public IActionResult ProfileUpdate(UserSnapshot Model)
        {
            try
            {
                var User = _IUserService.UserUpdate(Model);
                return new JsonResult(Model);


            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        [HttpGet("GetProfile/{UserID}")]
        public IActionResult SelectUser(Guid UserID)
        {
            try
            { 
                var User = _IUserService.SelectUser(UserID);
                return new JsonResult(User);


            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet("GetProfileByEmail/{EmailID}")]
        public IActionResult SelectUserUsingEmail(string EmailID)
        {
            try
            {
                var User = _IUserService.SelectUserByEmail(EmailID);
                if (User == null)
                    return new JsonResult(NotFound());
                else
                    return new JsonResult(User);


            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        [HttpGet("GetAttachment/{UserID}/{Type}")]
        public async Task<IActionResult> SelectAttachment(Guid UserID,FileCategory Type)
        {
            try
            {
                var _FileViewModel = _IUserService.SelectAttachment(UserID, Type);

                if (_FileViewModel != null)
                {
                    string hostedURL = HttpContext.Request.Scheme + "://" + HttpContext.Request.Host.Value + HttpContext.Request.PathBase;

                    string AttachFileName = UserID + "_" + _FileViewModel.FileName;
                    DirectoryInfo directory = new DirectoryInfo(hostingEnvironment.ContentRootPath + "/attachments");
                    bool FileName = directory.EnumerateFiles().Select(f => f.FullName.Contains(Convert.ToString(AttachFileName))).FirstOrDefault();
                    if (!FileName)
                    {
                        await System.IO.File.WriteAllBytesAsync(hostingEnvironment.ContentRootPath + "/attachments/" + AttachFileName, _FileViewModel.FileByte);
                    }
                    _FileViewModel.FileURL = hostedURL + "/attachments/" + AttachFileName;

                    return new JsonResult(_FileViewModel);
                }
                else
                {
                    return new JsonResult(NotFound());
                }
                


            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }


    }
}
