﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cycling.Global;
using Cycling.Model.Model.Snapshot;
using Cycling.Model.Model.ViewModels;
using Cycling.Service.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CyclingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly IAuthService _IAuthenticationService;
        public AuthenticationController(IAuthService _IAuthenticationService)
        {
            this._IAuthenticationService = _IAuthenticationService;
        }

        [HttpPost("SignIn")]
        public IActionResult SignIn(AuthSnapshot Model)
        {
            try
            {

                AuthViewModel authViewModel = _IAuthenticationService.SignIn(Model);
                return new JsonResult(authViewModel);

            }
            catch (Exception objerr)
            {
                return BadRequest(objerr);
            }
        }
        [HttpGet("ForgotPassword/{EmailID}")]
        public IActionResult ForgotPassword(string EmailID)
        {
            try
            {

                ForgotViewModel _ForgotViewModel = _IAuthenticationService.ForgotPassword(EmailID);
                if(_ForgotViewModel == null)
                {
                    return BadRequest("Email ID not found");
                }
                else
                {
                    return new JsonResult(_ForgotViewModel);
                }
               

            }
            catch (Exception objerr)
            {
                return BadRequest(objerr);
            }
        }

        [HttpGet("OTPValidate/{OTPNumber}/{OTPUserID}")]
        public IActionResult OTPValidation(int OTPNumber, int OTPUserID)
        {
            try
            {

               
                if (!OTP.Verification(OTPNumber,OTPUserID))
                {
                    return new JsonResult(false);
                }
                else
                {
                    return new JsonResult(true);
                }


            }
            catch (Exception objerr)
            {
                return BadRequest(objerr);
            }
        }
        [HttpGet("UserCreate")]
        public IActionResult UserCreate(string PhoneNumber, string Email)
        {
            try
            {
                var userID = OTP.UserCreate(PhoneNumber, Email);

                if (!OTP.SendOTP(userID))
                {
                    return new JsonResult(false);
                }
                else
                {
                    return new JsonResult(true);
                }


            }
            catch (Exception objerr)
            {
                return BadRequest(objerr);
            }
        }

        [HttpGet("SendOTP")]
        public IActionResult SendOTPUsingMobileNo(string PhoneNumber)
        {
            try
            {
                var userID = _IAuthenticationService.SendOTP(PhoneNumber);

                if (userID == 0 )
                {
                    return new JsonResult("User details not found");
                }
                else
                {
                    return new JsonResult(userID);
                }


            }
            catch (Exception objerr)
            {
                return BadRequest(objerr);
            }
        }

    }
}
