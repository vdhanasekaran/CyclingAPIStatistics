﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cycling.Service.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CyclingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CodedController : ControllerBase
    {
        private readonly ICodedService _ICodedService;
        public CodedController(ICodedService _ICodedService)
        {
            this._ICodedService = _ICodedService;
        }
        // GET: api/Coded/GetShop

        [HttpGet("GetShop")]
        public IActionResult SelectShop()
        {
            try
            {
                var User = _ICodedService.SelectShop();

                return new JsonResult(User);


            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        //

        // GET: api/Coded/GetGroup
        [HttpGet("GetGroup")]
        public IActionResult SelectGroup()
        {
            try
            {
                var User = _ICodedService.SelectGroup();

                return new JsonResult(User);


            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        //

        // GET: api/Coded/GetTeam
        [HttpGet("GetTeam")]
        public IActionResult SelectTeam()
        {
            try
            {
                var User = _ICodedService.SelectTeam();

                return new JsonResult(User);


            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        //

        // GET: api/Coded/GetAthleteType
        [HttpGet("GetAthleteType")]
        public IActionResult SelectCAthleteType()
        {
            try
            {
                var User = _ICodedService.SelectCAthleteType();

                return new JsonResult(User);


            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }

        //

        // GET: api/Coded/GetMetricFormats
        [HttpGet("GetMetricFormats")]
        public IActionResult SelectCMetricFormats()
        {
            try
            {
                var User = _ICodedService.SelectCMetricFormats();

                return new JsonResult(User);


            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }
        //

        // GET: api/Coded/GetSecurityQuestions
        [HttpGet("GetSecurityQuestions")]
        public IActionResult SelectSecurityQuestion()
        {
            try
            {
                var User = _ICodedService.SelectSecurityQuestion();

                return new JsonResult(User);


            }
            catch (Exception ex)
            {
                return BadRequest(ex);
            }
        }


    }
}
