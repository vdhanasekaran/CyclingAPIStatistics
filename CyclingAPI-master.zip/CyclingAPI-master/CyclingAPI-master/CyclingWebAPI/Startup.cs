using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Cycling.Model.DbContexts;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Microsoft.EntityFrameworkCore;
using Cycling.Repository.Interfaces;
using Cycling.Repository;
using Cycling.Service.Interfaces;
using Cycling.Service.Services;
using Cycling.Repository.Repository;
using Microsoft.Extensions.FileProviders;
using System.IO;
using Microsoft.AspNetCore.Http;

namespace CyclingWebAPI
{
    public class Startup
    {
        public Startup(IWebHostEnvironment Env, IConfiguration configuration)
        {
            var builder = new ConfigurationBuilder().SetBasePath(Env.ContentRootPath)
               .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                   .AddJsonFile($"appsettings.{Env.EnvironmentName}.json", optional: true)
                      .AddEnvironmentVariables().Build();
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddEntityFrameworkSqlServer();
            services.AddSwaggerGen(
              c => c.SwaggerDoc("v1", new OpenApiInfo { Title = "Cycling Track API", Description = "Aatral Creations ", Version = "v1" })
              );
            services.AddCors(options => options.AddPolicy("Access-Control-Allow-Origin", p => p.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin()));
            string DBconnectionstring = Configuration.GetConnectionString("DefaultConnection");
            services.AddDbContext<CyclingContext>((serviceProvider, options) =>
            {

                options.UseSqlServer(DBconnectionstring);

            });
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IAuthenticationRepository, AuthenticationRepository>();
            services.AddScoped<IAuthService, AuthService>();
            services.AddScoped<ICodedRepository, CodedRepository>();
            services.AddScoped<ICodedService, CodedService>();
            services.AddScoped<IStatisticsRepository, StatisticsRepository>();
            services.AddScoped<IStatisticsService, StatisticsService>();
            services.AddControllers().AddJsonOptions(option =>
            {
                option.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;



            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseRouting();
            app.UseCors(options => options.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());
            app.UseAuthorization();
            app.UseSwagger();

            if (env.IsProduction())
                app.UseStaticFiles();
            IApplicationBuilder app1 = app;
            StaticFileOptions options1 = new StaticFileOptions();
            options1.FileProvider = (IFileProvider)new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), "attachments"));
            options1.RequestPath = (PathString)"/attachments";
            app1.UseStaticFiles(options1);

            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Cycling Tracking ");

            });
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
