﻿using System;

namespace Cycling.Model
{
    public class Class1
    {
    }
}
