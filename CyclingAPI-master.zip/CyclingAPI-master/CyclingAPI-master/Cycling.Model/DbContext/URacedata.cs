﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model
{
    public class URacedata
    {
       public Guid? UserID { get; set; }
        public int? Time { get; set; }
        public decimal? Distance { get; set; }
        public decimal? Speed { get; set; }
        public int? Power { get; set; }
        public int? HeartRate { get; set; }
        public int? Cadence { get; set; }
        public int? TargetCadence { get; set; }
      
    }
}
