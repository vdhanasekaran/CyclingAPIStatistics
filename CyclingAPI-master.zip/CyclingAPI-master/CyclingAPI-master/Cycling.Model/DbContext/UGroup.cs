﻿using System;
using System.Collections.Generic;

namespace Cycling.Model.Models
{
    public partial class UGroup
    {
        public UGroup()
        {
            UUser = new HashSet<UUser>();
        }

        public Guid GroupId { get; set; }
        public string GroupName { get; set; }
        public DateTimeOffset? TimeStampModified { get; set; }
        public DateTimeOffset? TimeStampCreated { get; set; }

        public virtual ICollection<UUser> UUser { get; set; }
    }
}
