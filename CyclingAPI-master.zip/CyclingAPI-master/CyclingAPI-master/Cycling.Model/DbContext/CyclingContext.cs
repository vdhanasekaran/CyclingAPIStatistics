﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Cycling.Model.Models;
using Cycling.Model.Model.Mapping;
using Cycling.Model.Model;

namespace Cycling.Model.DbContexts
{
    public partial class CyclingContext : DbContext
    {
        public CyclingContext()
        {

        }

        public CyclingContext(DbContextOptions<CyclingContext> options)
            : base(options)
        {

        }

        public virtual DbSet<CAthleteType> CAthleteType { get; set; }
        public virtual DbSet<CMetricFormats> CMetricFormats { get; set; }
        public virtual DbSet<UGroup> UGroup { get; set; }
        public virtual DbSet<UIccadmin> UIccadmin { get; set; }
        public virtual DbSet<UShop> UShop { get; set; }
        public virtual DbSet<UTeam> UTeam { get; set; }
        public virtual DbSet<UUser> UUser { get; set; }
        public virtual DbSet<UUserFiles> UUserFiles { get; set; }
        public virtual DbSet<USecurityQuestion> USecurityQuestions { get; set; }
        public virtual DbSet<UUserTrainees> UUserTrainees { get; set; }
        public virtual DbSet<URacedata> URacedata { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

                optionsBuilder.UseSqlServer("Data Source=ServerNameOrIP;Initial Catalog=Cycling;Integrated Security=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration<CAthleteType>(new CAthleteTypeMap());
            modelBuilder.ApplyConfiguration<CMetricFormats>(new CMetricFormatsMap());
            modelBuilder.ApplyConfiguration<UGroup>(new UGroupMap());
            modelBuilder.ApplyConfiguration<UIccadmin>(new UIccadminMap());
            modelBuilder.ApplyConfiguration<UShop>(new UShopMap());
            modelBuilder.ApplyConfiguration<UTeam>(new UTeamMap());
            modelBuilder.ApplyConfiguration<UUser>(new UUserMap());
            modelBuilder.ApplyConfiguration<UUserFiles>(new UUserFilesMap());
            modelBuilder.ApplyConfiguration<UUserTrainees>(new UUserTraineesMap());
            modelBuilder.ApplyConfiguration<USecurityQuestion>(new USecurityQuestionMap());
            modelBuilder.ApplyConfiguration<URacedata>(new URacedataMap());
        }
    }
}
