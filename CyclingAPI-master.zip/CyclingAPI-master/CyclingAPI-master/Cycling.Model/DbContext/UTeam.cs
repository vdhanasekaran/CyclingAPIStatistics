﻿using System;
using System.Collections.Generic;

namespace Cycling.Model.Models
{
    public partial class UTeam
    {
        public UTeam()
        {
            UUser = new HashSet<UUser>();
        }

        public Guid TeamId { get; set; }
        public string TeamName { get; set; }
        public DateTimeOffset? TimeStampModified { get; set; }
        public DateTimeOffset? TimeStampCreated { get; set; }

        public virtual ICollection<UUser> UUser { get; set; }
    }
}
