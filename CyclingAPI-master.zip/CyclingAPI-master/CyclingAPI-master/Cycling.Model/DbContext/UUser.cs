﻿using System;
using System.Collections.Generic;

namespace Cycling.Model.Models
{
    public partial class UUser
    {
        public UUser()
        {
            UUserFiles = new HashSet<UUserFiles>();
            UUserTrainees = new HashSet<UUserTrainees>();
        }

        public Guid UserId { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Gender { get; set; }
        public string Locations { get; set; }
        public long Zipcode { get; set; }
        public string Nation { get; set; }
        public string Region { get; set; }
        public string City { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }
        public string Password { get; set; }
        public string NickName { get; set; }
        public Guid? UTeamId { get; set; }
        public Guid? UShopId { get; set; }
        public Guid? UGroupId { get; set; }
        public Guid? CAthleteTypeId { get; set; }
        public Guid? CMetricFormatsId { get; set; }
        public string SecurityQuestion { get; set; }
        public string Answer { get; set; }
        public int ? OTPUserID { get; set; }
        
        public DateTimeOffset? TimeStampModified { get; set; }
        public DateTimeOffset? TimeStampCreated { get; set; }

        public virtual CAthleteType CAthleteType { get; set; }
        public virtual CMetricFormats CMetricFormats { get; set; }
        public virtual UGroup UGroup { get; set; }
        public virtual UShop UShop { get; set; }
        public virtual UTeam UTeam { get; set; }
        public virtual ICollection<UUserFiles> UUserFiles { get; set; }
        public virtual ICollection<UUserTrainees> UUserTrainees { get; set; }
    }
}
