﻿using System;
using System.Collections.Generic;

namespace Cycling.Model.Models
{
    public partial class CMetricFormats
    {
        public CMetricFormats()
        {
            UUser = new HashSet<UUser>();
        }

        public Guid MetricFormatId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<UUser> UUser { get; set; }
    }
}
