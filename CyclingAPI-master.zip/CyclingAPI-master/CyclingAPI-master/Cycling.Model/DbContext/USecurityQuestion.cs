﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Models
{
    public class USecurityQuestion
    {
        public Guid SecurityID { get; set; }
        public string QuestionName { get; set; }
        public bool? IsActive { get; set; }
    }
}
