﻿using System;
using System.Collections.Generic;

namespace Cycling.Model.Models
{
    public partial class UUserFiles
    {
        public Guid FileId { get; set; }
        public Guid UserId { get; set; }
        public byte[] Certificate { get; set; }
        public byte[] DeadLineCertificate { get; set; }
        public byte[] TetanusProphylctis { get; set; }

        public string DeadLineCertificateName { get; set; }
        public string TetanusProphylctisName { get; set; }
        public string CertificateName { get; set; }

         public DateTimeOffset? TimeStampModified { get; set; }
        public DateTimeOffset? TimeStampCreated { get; set; }

        public virtual UUser User { get; set; }
    }
}
