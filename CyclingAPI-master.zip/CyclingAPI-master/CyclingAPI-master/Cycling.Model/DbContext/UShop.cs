﻿using System;
using System.Collections.Generic;

namespace Cycling.Model.Models
{
    public partial class UShop
    {
        public UShop()
        {
            UUser = new HashSet<UUser>();
        }

        public Guid ShopId { get; set; }
        public string ShopName { get; set; }
        public DateTimeOffset? TimeStampModified { get; set; }
        public DateTimeOffset? TimeStampCreated { get; set; }

        public virtual ICollection<UUser> UUser { get; set; }
    }
}
