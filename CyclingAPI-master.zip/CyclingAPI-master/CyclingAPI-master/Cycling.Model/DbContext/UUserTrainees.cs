﻿using System;
using System.Collections.Generic;

namespace Cycling.Model.Models
{
    public partial class UUserTrainees
    {
        public Guid UserTraineeId { get; set; }
        public Guid UserId { get; set; }
        public Guid IccadminId { get; set; }
        public DateTimeOffset? TimeStampModified { get; set; }
        public DateTimeOffset? TimeStampCreated { get; set; }

        public virtual UIccadmin Iccadmin { get; set; }
        public virtual UUser User { get; set; }
    }
}
