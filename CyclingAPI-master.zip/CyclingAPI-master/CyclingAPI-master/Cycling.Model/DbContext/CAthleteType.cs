﻿using System;
using System.Collections.Generic;

namespace Cycling.Model.Models
{
    public partial class CAthleteType
    {
        public CAthleteType()
        {
            UUser = new HashSet<UUser>();
        }

        public Guid AthleteTypeId { get; set; }
        public string Name { get; set; }
        public bool? IsActive { get; set; }

        public virtual ICollection<UUser> UUser { get; set; }
    }
}
