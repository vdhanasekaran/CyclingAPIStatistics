﻿using Cycling.Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
    class UTeamMap : IEntityTypeConfiguration<UTeam>
    {
        public void Configure(EntityTypeBuilder<UTeam> builder)
        {
            builder.HasKey(e => e.TeamId)
                   .HasName("PK__uTeam__123AE7B9CA09B521");

            builder.ToTable("uTeam");

            builder.Property(e => e.TeamId)
                .HasColumnName("TeamID")
                .ValueGeneratedNever();

            builder.Property(e => e.TeamName)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);
        }
    }
}
