﻿using Cycling.Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
    public class UGroupMap : IEntityTypeConfiguration<UGroup>
    {
        public void Configure(EntityTypeBuilder<UGroup> entity)
        {
            entity.HasKey(e => e.GroupId)
                     .HasName("PK__uGroup__149AF30ACF883AD3");

            entity.ToTable("uGroup");

            entity.Property(e => e.GroupId)
                .HasColumnName("GroupID")
                .ValueGeneratedNever();

            entity.Property(e => e.GroupName)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);
        }
    }
}
