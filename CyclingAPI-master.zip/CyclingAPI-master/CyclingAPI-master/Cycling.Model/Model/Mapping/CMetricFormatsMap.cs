﻿using Cycling.Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
    public class CMetricFormatsMap : IEntityTypeConfiguration<CMetricFormats>
    {
        public void Configure(EntityTypeBuilder<CMetricFormats> builder)
        {
            builder.HasKey(e => e.MetricFormatId)
                                .HasName("PK__cMetricF__0C637DCCF96EB6A5");

            builder.ToTable("cMetricFormats");

            builder.Property(e => e.MetricFormatId)
                .HasColumnName("MetricFormatID")
                .ValueGeneratedNever();

            builder.Property(e => e.Name)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);


        }
    }


}
 