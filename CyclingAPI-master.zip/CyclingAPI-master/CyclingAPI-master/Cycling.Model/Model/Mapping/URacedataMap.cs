﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
   public  class URacedataMap :IEntityTypeConfiguration<URacedata>
    {
        public void Configure(EntityTypeBuilder<URacedata> entity)
        {
            entity.HasKey(e => e.UserID);
            entity.Property(e => e.TargetCadence).HasColumnName("TargetCadence");

            entity.Property(e => e.Speed).HasColumnName("Speed");

            entity.Property(e => e.Power).HasColumnName("Power");
            entity.Property(e => e.HeartRate).HasColumnName("HeartRate");

            entity.Property(e => e.Time).HasColumnName("Time");
            entity.Property(e => e.Cadence).HasColumnName("Cadence");
            entity.Property(e => e.Distance).HasColumnName("Distance");

            //entity.HasKey();
            entity.ToTable("URacedata");

            entity.Property(e => e.UserID)
                .HasColumnName("UserID")
                .ValueGeneratedNever();


        }
        }
    }
