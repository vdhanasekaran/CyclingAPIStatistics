﻿using Cycling.Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
   public class UShopMap:IEntityTypeConfiguration<UShop>
    {

       public void  Configure(EntityTypeBuilder<UShop> builder)
        {
            builder.HasKey(e => e.ShopId)
                    .HasName("PK__uShop__67C55629ADF303B0");

            builder.ToTable("uShop");

            builder.Property(e => e.ShopId)
                .HasColumnName("ShopID")
                .ValueGeneratedNever();

            builder.Property(e => e.ShopName)
                                .IsRequired()
                                .HasMaxLength(30)
                                .IsUnicode(false);
        }
    }
}


