﻿using Cycling.Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
  public  class UUserTraineesMap: IEntityTypeConfiguration<UUserTrainees>
    {
        public void Configure(EntityTypeBuilder<UUserTrainees> entity)
        {
            entity.HasKey(e => e.UserTraineeId)
                  .HasName("PK__uUserTra__A5C2ECC8CBEC9DC2");

            entity.ToTable("uUserTrainees");

            entity.Property(e => e.UserTraineeId)
                .HasColumnName("UserTraineeID")
                .ValueGeneratedNever();

            entity.Property(e => e.IccadminId).HasColumnName("ICCAdminID");

            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.Iccadmin)
                .WithMany(p => p.UUserTrainees)
                .HasForeignKey(d => d.IccadminId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ICCAdminUser");

            entity.HasOne(d => d.User)
                .WithMany(p => p.UUserTrainees)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TraineeUser");
        }
    }
}
