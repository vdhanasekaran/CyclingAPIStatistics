﻿using Cycling.Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
    public class UUserFilesMap : IEntityTypeConfiguration<UUserFiles>
    {
        public void Configure(EntityTypeBuilder<UUserFiles> entity)
        {
            entity.HasKey(e => e.FileId)
                   .HasName("PK__uUserFil__6F0F989FA4E8A927");

            entity.ToTable("uUserFiles");

            entity.Property(e => e.FileId)
                .HasColumnName("FileID")
                .ValueGeneratedNever();

            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.User)
                .WithMany(p => p.UUserFiles)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_FileUser");
    
        }
 } }
