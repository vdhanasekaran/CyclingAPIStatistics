﻿using Cycling.Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
   
    public  class UUserMap : IEntityTypeConfiguration<UUser>
    {
        public void Configure(EntityTypeBuilder<UUser> entity)
        {
            entity.HasKey(e => e.UserId)
                       .HasName("PK__uUser__1788CCACA770EF22");

            entity.ToTable("uUser");

            entity.Property(e => e.UserId)
                .HasColumnName("UserID")
                .ValueGeneratedNever();

            entity.Property(e => e.Answer)
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.Property(e => e.CAthleteTypeId).HasColumnName("cAthleteTypeID");

            entity.Property(e => e.CMetricFormatsId).HasColumnName("cMetricFormatsID");

            entity.Property(e => e.City)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.Property(e => e.ContactNo)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.Property(e => e.Email)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.Property(e => e.Gender)
                .IsRequired()
                .HasMaxLength(10)
                .IsUnicode(false);

            entity.Property(e => e.Locations)
                .IsRequired()
                .HasColumnName("locations")
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.Property(e => e.Name)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.Nation)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.Property(e => e.NickName)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.Password)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.Region)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.Property(e => e.SecurityQuestion)
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.Property(e => e.Surname)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            //entity.Property(e => e.OTPUserID)
            //    .IsRequired()
            //    .HasMaxLength(100)
            //    .IsUnicode(false);

            entity.Property(e => e.UGroupId).HasColumnName("uGroupID");

            entity.Property(e => e.UShopId).HasColumnName("uShopID");

            entity.Property(e => e.UTeamId).HasColumnName("uTeamID");

            entity.HasOne(d => d.CAthleteType)
                .WithMany(p => p.UUser)
                .HasForeignKey(d => d.CAthleteTypeId)
                .HasConstraintName("FK_UserAthlete");

            entity.HasOne(d => d.CMetricFormats)
                .WithMany(p => p.UUser)
                .HasForeignKey(d => d.CMetricFormatsId)
                .HasConstraintName("FK_UserMetric");

            entity.HasOne(d => d.UGroup)
                .WithMany(p => p.UUser)
                .HasForeignKey(d => d.UGroupId)
                .HasConstraintName("FK_UserGroup");

            entity.HasOne(d => d.UShop)
                .WithMany(p => p.UUser)
                .HasForeignKey(d => d.UShopId)
                .HasConstraintName("FK_UserShop");

            entity.HasOne(d => d.UTeam)
                .WithMany(p => p.UUser)
                .HasForeignKey(d => d.UTeamId)
                .HasConstraintName("FK_UserTeam");

        }
    }
}
