﻿using Cycling.Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
    class UIccadminMap :IEntityTypeConfiguration<UIccadmin>
    {
        public void Configure(EntityTypeBuilder<UIccadmin> entity)
        {
            entity.HasKey(e => e.AdminId)
                      .HasName("PK__uICCAdmi__719FE4E8684AA841");

            entity.ToTable("uICCAdmin");

            entity.Property(e => e.AdminId)
                .HasColumnName("AdminID")
                .ValueGeneratedNever();

            entity.Property(e => e.Answer)
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.Property(e => e.City)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.Property(e => e.ContactNo)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.Property(e => e.Email)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.Property(e => e.EmpId)
                .HasColumnName("EmpID")
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.Property(e => e.Gender)
                .IsRequired()
                .HasMaxLength(10)
                .IsUnicode(false);

            entity.Property(e => e.Locations)
                .IsRequired()
                .HasColumnName("locations")
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.Property(e => e.Name)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.Nation)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.Property(e => e.NickName)
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.Password)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.Region)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.Property(e => e.SecurityQuestion)
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.Property(e => e.Surname)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);
        }
    }
}
