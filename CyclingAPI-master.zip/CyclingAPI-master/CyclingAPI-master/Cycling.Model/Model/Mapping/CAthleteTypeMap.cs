﻿using Cycling.Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
    public class CAthleteTypeMap : IEntityTypeConfiguration<CAthleteType>
    {
        public void Configure(EntityTypeBuilder<CAthleteType> builder)
        {
            builder.HasKey(e => e.AthleteTypeId)
                .HasName("PK__cAthlete__5E95EC4773A03066");

            builder.ToTable("cAthleteType");

            builder.Property(e => e.AthleteTypeId)
                .HasColumnName("AthleteTypeID")
                .ValueGeneratedNever();

            builder.Property(e => e.Name)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);
        }
    }
}
