﻿using Cycling.Model.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Mapping
{
   public class USecurityQuestionMap :IEntityTypeConfiguration<USecurityQuestion>
    {
        public void Configure(EntityTypeBuilder<USecurityQuestion> builder)
        {
            builder.HasKey(e => e.SecurityID)
                                .HasName("PK__USecurit__9F8B0950AEBDBA64");

            builder.ToTable("USecurityQuestion");

            builder.Property(e => e.SecurityID)
                .HasColumnName("SecurityID")
                .ValueGeneratedNever();

            builder.Property(e => e.QuestionName)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);


        }
    }
}
