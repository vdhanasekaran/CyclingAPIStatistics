﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.Snapshot
{
    public class AttachmentSnapshot
    {


        public string FileByte { get; set; }
        public string FileName { get; set; }
        public Guid? UserID { get; set; }
        public string Category { get; set; }
    }
}
