﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.ViewModels
{
    public class HeartRateViewModel
    {
        public List<AverageHeartRateViewModel> AverageHeartRateList { get; set; }

        public double? AverageHeartRate { get; set; }

        public double? MaximumHeartRate { get; set; }

        public double? MinimumHeartRate { get; set; }
    }
}
