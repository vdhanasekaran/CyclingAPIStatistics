﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.ViewModels
{
    public class AuthViewModel
    {
        public Guid? UserId { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Gender { get; set; }
        public string Email { get; set; }
        public bool IsAuthenticationSuccess { get; set; } = false;
        
        public string ExceptionMessage { get; set; }
        public string Token { get; set; }
    }
}
