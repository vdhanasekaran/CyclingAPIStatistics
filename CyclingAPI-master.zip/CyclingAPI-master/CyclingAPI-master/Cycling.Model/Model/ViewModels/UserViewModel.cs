﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.ViewModels
{
    public class UserViewModel
    {
        public Guid ? UserId { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Gender { get; set; }
        public string Locations { get; set; }
        public long Zipcode { get; set; }
        public string Nation { get; set; }
        public string Region { get; set; }
        public string City { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }
        public string Password { get; set; }
        public string NickName { get; set; }
        public string UTeamName { get; set; }
        public string UShopName { get; set; }
        public string UGroupName { get; set; }
        public string CAthleteTypeName { get; set; }
        public string CMetricFormatsName { get; set; }
        public string SecurityQuestion { get; set; }
        public string Answer { get; set; }
        public DateTimeOffset? TimeStampModified { get; set; }
        public DateTimeOffset? TimeStampCreated { get; set; }
    }
}
