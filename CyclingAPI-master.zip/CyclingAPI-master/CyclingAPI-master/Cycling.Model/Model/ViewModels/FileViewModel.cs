﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.ViewModels
{
   public class FileViewModel
    {
        public byte[] FileByte { get; set; }
        public string FileName { get; set; }
        public string FileURL { get; set; }
    }
}
