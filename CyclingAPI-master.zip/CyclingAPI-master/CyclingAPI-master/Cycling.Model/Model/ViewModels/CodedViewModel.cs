﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.ViewModels
{
   public class CodedViewModel
    {
        public Guid ? CodeID { get; set; }
        public string CodeValue { get; set; }
    }
}
