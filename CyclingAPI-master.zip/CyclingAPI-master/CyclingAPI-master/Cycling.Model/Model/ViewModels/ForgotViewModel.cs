﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.ViewModels
{
   public class ForgotViewModel
    {
        public string Email { get; set; }
        public Guid? UserId { get; set; }
        public string SecurityQuestion { get; set; }
        public string Answer { get; set; }
        public int? OTPUserID { get; set; }
    }
}
