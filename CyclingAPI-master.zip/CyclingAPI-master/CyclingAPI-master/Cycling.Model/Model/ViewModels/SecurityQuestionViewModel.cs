﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.ViewModels
{
    public class SecurityQuestionViewModel
    {
        public string Question { get; set; }
        public string Answer { get; set; }
    }
}
