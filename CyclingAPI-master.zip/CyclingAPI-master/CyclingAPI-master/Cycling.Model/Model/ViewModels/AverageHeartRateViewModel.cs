﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Model.Model.ViewModels
{
    public class AverageHeartRateViewModel
    {
        public double Average { get; set; }

        public decimal Distance { get; set; }
    }
}
