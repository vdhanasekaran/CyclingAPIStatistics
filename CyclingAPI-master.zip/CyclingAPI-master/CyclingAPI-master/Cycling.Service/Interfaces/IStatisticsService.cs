﻿using Cycling.Model.Model.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Service.Interfaces
{
  public  interface IStatisticsService
    {
        List<RaceDataViewModel> SelectRacedata(Guid UserID);

        HeartRateViewModel GetHeartRateDetails(Guid userId);
    }
}
