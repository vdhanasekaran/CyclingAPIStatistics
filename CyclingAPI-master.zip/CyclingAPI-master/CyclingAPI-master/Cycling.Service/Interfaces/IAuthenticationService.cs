﻿using Cycling.Model.Model.Snapshot;
using Cycling.Model.Model.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Service.Interfaces
{
    public interface IAuthService
    {
        AuthViewModel SignIn(AuthSnapshot Model);
        ForgotViewModel ForgotPassword(string EmailID);
        int SendOTP(string MobileNo);
    }
       
}
