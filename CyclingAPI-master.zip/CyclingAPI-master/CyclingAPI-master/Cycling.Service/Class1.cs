﻿using System;

namespace Cycling.Service
{
    public class Class1
    {
    }
}
