﻿using Cycling.Model.Model.ViewModels;
using Cycling.Repository.Interfaces;
using Cycling.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Service.Services
{
   public class CodedService: ICodedService
    {
        private readonly ICodedRepository _ICodedRepository;
        public CodedService(ICodedRepository _ICodedRepository)
        {
            this._ICodedRepository = _ICodedRepository;
        }
       public List<CodedViewModel> SelectGroup()
        {
            return _ICodedRepository.SelectGroup();
        }

        public List<CodedViewModel> SelectShop()
        {
            return _ICodedRepository.SelectShop();
        }

        public List<CodedViewModel> SelectTeam()
        {
            return _ICodedRepository.SelectTeam();
        }
        public List<CodedViewModel> SelectCAthleteType()
        {
            return _ICodedRepository.SelectCAthleteType();
        }
        public List<CodedViewModel> SelectCMetricFormats()
        {
            return _ICodedRepository.SelectCMetricFormats();
        }
        public List<CodedViewModel> SelectSecurityQuestion()
        {
            return _ICodedRepository.SelectSecurityQuestion();
        }
    }
}
