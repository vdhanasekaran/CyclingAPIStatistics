﻿using Cycling.Global;
using Cycling.Model.Model.Snapshot;
using Cycling.Model.Model.ViewModels;
using Cycling.Repository.Interfaces;
using Cycling.Service.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Service.Services
{
    public class AuthService:IAuthService
    {
        private readonly IAuthenticationRepository _IAuthenticationRepository;
        private IConfiguration Configuration = null;
        public AuthService(IAuthenticationRepository _IAuthenticationRepository, IConfiguration Configuration)
        {
            this._IAuthenticationRepository = _IAuthenticationRepository;
            this.Configuration = Configuration;
        }
        public AuthViewModel SignIn(AuthSnapshot Model)
        {
            AuthViewModel _AuthViewModel = null;
            if (!string.IsNullOrEmpty(Model.Email) && !string.IsNullOrEmpty(Model.Password))
            {
                 _AuthViewModel = _IAuthenticationRepository.SignIn(Model);
                if (_AuthViewModel.IsAuthenticationSuccess)
                {
                    _AuthViewModel = _IAuthenticationRepository.GetUserInfo(_AuthViewModel.UserId ?? Guid.Empty);

                }
                else
                {
                    _AuthViewModel.IsAuthenticationSuccess = false;
                }
            }
            else
            {
                _AuthViewModel.IsAuthenticationSuccess = false;
            }


            return _AuthViewModel;
        }
       public  ForgotViewModel ForgotPassword(string EmailID)
        {
            
            if (string.IsNullOrEmpty(EmailID))
            {
                throw new Exception("Email ID should not be null");
            }
            else
              return _IAuthenticationRepository.ForgotPassword(EmailID);
               
                

        }
        public int SendOTP(string MobileNo)
        {
            int  OTPUserID = 0;
            Dictionary<string, string> User = _IAuthenticationRepository.SelectOTPuserID(MobileNo);
            string EmailID = null;
           
            if(User != null)
            {
                if (User.ContainsKey("EmailID") && User.ContainsKey("OTPUserID"))
                {
                    EmailID  = User["EmailID"];
                    OTPUserID = Convert.ToInt32(User["OTPUserID"]);
                }
                MailModel Model = new MailModel();
                OTP.SendOTP(OTPUserID);
                Model.Subject = " ***---Forgot Password ---*** ";
                Model.Recipient = EmailID.Trim();
                Model.Body = "One Time Password has been sent your registred Mobile number please check ";
                Model.Host = Configuration["SMTPMailServer"];
                Model.Username = Configuration["SMTPServerUser"];
                Model.Password = Configuration["SMTPServerPwd"];
                Model.Sender = Configuration["SMTPServerUser"];
                Model.Port = Convert.ToInt32(Configuration["SMTPPort"]);

                MailHelper Helper = new MailHelper();
                Helper.SendEmail(Model);
                
            }
            return OTPUserID;
        }

    }
}
