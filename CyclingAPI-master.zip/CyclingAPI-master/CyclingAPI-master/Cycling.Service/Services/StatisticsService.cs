﻿using Cycling.Model.Model.ViewModels;
using Cycling.Repository.Interfaces;
using Cycling.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Service.Services
{
    public class StatisticsService : IStatisticsService
    {
        private readonly IStatisticsRepository _IStatisticsRepository;
        public StatisticsService(IStatisticsRepository _IStatisticsRepository)
        {
            this._IStatisticsRepository = _IStatisticsRepository;
        }

        public List<RaceDataViewModel> SelectRacedata(Guid UserID)
        {
            if (UserID == Guid.Empty)
                throw new Exception(" User ID should be contains values");
            else

                return _IStatisticsRepository.SelectRacedata(UserID);
        }

        public HeartRateViewModel GetHeartRateDetails(Guid userId)
        {
            return new HeartRateViewModel
            {
                AverageHeartRateList = _IStatisticsRepository.AverageHearRateByDistance(userId),
                AverageHeartRate = _IStatisticsRepository.AverageHeartRate(userId),
                MaximumHeartRate = _IStatisticsRepository.MaxHeartRate(userId),
                MinimumHeartRate = _IStatisticsRepository.MinHeartRate(userId)
            };
        }
    }
}
