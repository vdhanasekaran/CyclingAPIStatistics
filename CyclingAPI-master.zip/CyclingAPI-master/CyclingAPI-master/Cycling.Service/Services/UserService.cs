﻿using Cycling.Global;
using Cycling.Model.Model.Snapshot;
using Cycling.Model.Model.ViewModels;
using Cycling.Repository.Interfaces;
using Cycling.Service.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using static Cycling.Global.CommonEnum;

namespace Cycling.Service.Services
{
   public class UserService :IUserService
    {
       private readonly IUserRepository _IUserRepositoty;
       public UserService(IUserRepository _IUserRepositoty)
        {
            this._IUserRepositoty = _IUserRepositoty;
        }
        public UserSnapshot SignUp(UserSnapshot Model)
        {
            if (Model == null)
            {
                throw new Exception("User detail should contain values");
            }

            else
            {
                Model.OTPUserID = OTP.UserCreate(Model.ContactNo, Model.Email);
                return _IUserRepositoty.SignUp(Model);
            }
             
        }
        public UserSnapshot UserUpdate(UserSnapshot Model)
        {
            if (Model == null)
                throw new Exception("User detail should contain values");
            else
                return _IUserRepositoty.UserUpdate(Model);

        }
        public UserViewModel SelectUser(Guid UserID)
        {
            if (UserID == null || UserID == Guid.Empty)
                throw new Exception("UserID  should not be empty");
            else
                return _IUserRepositoty.SelectUser(UserID);

        }
        public bool EmailAleadyExists(string EmailID)
        {
            if(string.IsNullOrEmpty(EmailID))
                throw new Exception("Email ID  should not be empty");
            else
                return _IUserRepositoty.EmailAleadyExists(EmailID);
        }
       public UserViewModel SelectUserByEmail(string Email)
        {
            if (string.IsNullOrEmpty(Email))
                throw new Exception("Email ID  should not be empty");
            else
                return _IUserRepositoty.SelectUserByEmail(Email);
        }
        public FileViewModel SelectAttachment(Guid UserID, FileCategory type)
        {
            if (UserID == null || UserID == Guid.Empty)
                throw new Exception("UserID ID  should not be empty");

            else if (type == null)
                throw new Exception("FileCategory ID  should not be empty");
            else
                return _IUserRepositoty.SelectAttachment(UserID,type);
        }
    }
}
