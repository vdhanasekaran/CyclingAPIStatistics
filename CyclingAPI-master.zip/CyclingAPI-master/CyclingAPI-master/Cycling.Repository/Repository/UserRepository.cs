﻿using AutoMapper;
using Cycling.Global;
using Cycling.Model.DbContexts;
using Cycling.Model.Model.Snapshot;
using Cycling.Model.Model.ViewModels;
using Cycling.Model.Models;
using Cycling.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using static Cycling.Global.CommonEnum;

namespace Cycling.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly CyclingContext _CyclingContext;
        public UserRepository(CyclingContext _CyclingContext)
        {
            this._CyclingContext = _CyclingContext;
        }

        #region User Registration/Sign-up
        public UserSnapshot SignUp(UserSnapshot Model)
        {
            try
            {

                UUser _Uuser = new UUser();
                Model.UserId = Guid.NewGuid();
                _Uuser.UserId = Model.UserId ?? Guid.NewGuid();
                _Uuser.TimeStampCreated = DateTime.UtcNow;
                _Uuser.Password = Crypto.DoEncrypt(Model.Password);
                _Uuser.Answer = Model.Answer;
                _Uuser.SecurityQuestion = Model.SecurityQuestion;
                _Uuser.Region = Model.Region;
                _Uuser.Surname = Model.Surname;
                _Uuser.NickName = Model.NickName;
                _Uuser.Nation = Model.Nation;
                _Uuser.Name = Model.Name;
                _Uuser.Gender = Model.Gender;
                _Uuser.Email = Model.Email;
                _Uuser.City = Model.City;
                _Uuser.ContactNo = Model.ContactNo;
                _Uuser.Locations = Model.Locations;
                _Uuser.OTPUserID = Model.OTPUserID;
                Guid GroupID = (from g in _CyclingContext.UGroup where g.GroupName == Model.UGroupName select g.GroupId).FirstOrDefault();
                if (!string.IsNullOrEmpty(Model.UGroupName))
                {
                    //Checking the Group Name from Table if it is not available then we are creating the new group from the Db 

                    if (GroupID == null || GroupID == Guid.Empty)
                    {
                        UGroup uGroup = new UGroup();
                        uGroup.GroupId = Guid.NewGuid();
                        uGroup.GroupName = Model.UGroupName;
                        uGroup.TimeStampCreated = DateTime.UtcNow;
                        GroupID = uGroup.GroupId;
                        _CyclingContext.UGroup.Add(uGroup);
                        _CyclingContext.SaveChanges();
                    }
                }
                //
                Guid TeamID = (from T in _CyclingContext.UTeam where T.TeamName == Model.UTeamName select T.TeamId).FirstOrDefault();
                if (!string.IsNullOrEmpty(Model.UTeamName))
                {
                    //Checking the Team Name from Table if it is not available then we are creating the new team from the Db 

                    if (TeamID == null || TeamID == Guid.Empty)
                    {
                        UTeam _UTeam = new UTeam();
                        _UTeam.TeamId = Guid.NewGuid();
                        _UTeam.TeamName = Model.UTeamName;
                        _UTeam.TimeStampCreated = DateTime.UtcNow;
                        TeamID = _UTeam.TeamId;
                        _CyclingContext.UTeam.Add(_UTeam);
                        _CyclingContext.SaveChanges();
                    }
                    //
                }
                //Checking the Shop Name from Table if it is not available then we are creating the new Shop from the Db 
                Guid ShopID = (from g in _CyclingContext.UShop where g.ShopName == Model.UShopName select g.ShopId).FirstOrDefault();
                if (!string.IsNullOrEmpty(Model.UShopName))
                {

                    if (ShopID == null || ShopID == Guid.Empty)
                    {
                        UShop _UShop = new UShop();
                        _UShop.ShopId = Guid.NewGuid();
                        _UShop.ShopName = Model.UShopName;
                        _UShop.TimeStampCreated = DateTime.UtcNow;
                        ShopID = _UShop.ShopId;
                        _CyclingContext.UShop.Add(_UShop);
                        _CyclingContext.SaveChanges();
                    }
                }
                //

                //Checking the Metric Format Name from Table if it is not available then we are creating the new Metric Format from the Db 
                Guid CMetricFormatsId = (from g in _CyclingContext.CMetricFormats where g.Name == Model.CMetricFormatsName select g.MetricFormatId).FirstOrDefault();
                if (!string.IsNullOrEmpty(Model.CMetricFormatsName))
                {


                    if (CMetricFormatsId == null || CMetricFormatsId == Guid.Empty)
                    {
                        CMetricFormats _CMetricFormats = new CMetricFormats();
                        _CMetricFormats.MetricFormatId = Guid.NewGuid();
                        _CMetricFormats.Name = Model.CMetricFormatsName;
                        _CMetricFormats.IsActive = true;
                        CMetricFormatsId = _CMetricFormats.MetricFormatId;
                        _CyclingContext.CMetricFormats.Add(_CMetricFormats);
                        _CyclingContext.SaveChanges();
                    }
                }

                //


                //Checking the Metric Format Name from Table if it is not available then we are creating the new Metric Format from the Db 
                Guid CAthleteTypeId = (from g in _CyclingContext.CAthleteType where g.Name == Model.CAthleteTypeName select g.AthleteTypeId).FirstOrDefault();
                if (!string.IsNullOrEmpty(Model.CAthleteTypeName))
                {



                    if (CAthleteTypeId == null || CAthleteTypeId == Guid.Empty)
                    {
                        CAthleteType _CAthleteType = new CAthleteType();
                        _CAthleteType.AthleteTypeId = Guid.NewGuid();
                        _CAthleteType.Name = Model.CAthleteTypeName;
                        _CAthleteType.IsActive = true;
                         CAthleteTypeId = _CAthleteType.AthleteTypeId;
                        _CyclingContext.CAthleteType.Add(_CAthleteType);
                        _CyclingContext.SaveChanges();
                    }

                }
                //
                _Uuser.CMetricFormatsId = CMetricFormatsId;
                _Uuser.UGroupId = GroupID;
                _Uuser.UShopId = ShopID;
                _Uuser.UTeamId = TeamID;
                _Uuser.CAthleteTypeId = CAthleteTypeId;
                _Uuser.Zipcode = Model.Zipcode;

                var User = _CyclingContext.UUser.Add(_Uuser);
                _CyclingContext.SaveChanges();
                
                // used for Attachment insert into the  uuserfiles table
                /*Certificate = 1,
                DeadLineCertificate = 2,
                TetanusProphylctis = 3*/

                if (Model.FileAttach.Count > 0)
                {
                    UUserFiles _UserFiles = null;
                    if (Model.FileAttach[0].FileByte != null)
                    {
                        _UserFiles = new UUserFiles();
                        _UserFiles.FileId = Guid.NewGuid();
                        _UserFiles.TimeStampCreated = DateTime.UtcNow;
                        _UserFiles.UserId = Model.UserId ?? Guid.Empty;
                        for (int i = 0; i < Model.FileAttach.Count; i++)
                        {
                            switch (Model.FileAttach[i].Category)
                            {
                                case "1":
                                    _UserFiles.Certificate = Convert.FromBase64String(Model.FileAttach[i].FileByte);
                                    _UserFiles.CertificateName = Model.FileAttach[i].FileName;
                                        
                                    break;
                                case "2":
                                    _UserFiles.DeadLineCertificate = Convert.FromBase64String(Model.FileAttach[i].FileByte);
                                    _UserFiles.DeadLineCertificateName = Model.FileAttach[i].FileName;
                                    break;
                                case "3":
                                    _UserFiles.TetanusProphylctis = Convert.FromBase64String(Model.FileAttach[i].FileByte);
                                    _UserFiles.TetanusProphylctisName = Model.FileAttach[i].FileName;
                                    break;

                            }
                        }
                    }


                    _CyclingContext.UUserFiles.Add(_UserFiles);
                    _CyclingContext.SaveChanges();

                }

                return Model;



            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
        #endregion

        #region User Update
        public UserSnapshot UserUpdate(UserSnapshot Model)
        {
            try
            {

                UUser _Uuser = new UUser();
                _Uuser.UserId = Model.UserId ?? Guid.NewGuid();
                _Uuser.TimeStampModified = DateTime.UtcNow;
                _Uuser.Password = Crypto.DoEncrypt(Model.Password);
                _Uuser.Answer = Model.Answer;
                _Uuser.SecurityQuestion = Model.SecurityQuestion;
                _Uuser.Region = Model.Region;
                _Uuser.Surname = Model.Surname;
                _Uuser.NickName = Model.NickName;
                _Uuser.Nation = Model.Nation;
                _Uuser.Name = Model.Name;
                _Uuser.Gender = Model.Gender;
                _Uuser.Email = Model.Email;
                _Uuser.City = Model.City;
                //_Uuser.CMetricFormatsId = Model.CMetricFormatsId;
                _Uuser.ContactNo = Model.ContactNo;
                _Uuser.Locations = Model.Locations;
                //_Uuser.UGroupId = Model.UGroupId;
                //_Uuser.UShopId = Model.UShopId;
                //_Uuser.UTeamId = Model.UTeamId;
                //_Uuser.CAthleteTypeId = Model.CAthleteTypeId;
                _Uuser.Zipcode = Model.Zipcode;

                var User = _CyclingContext.UUser.Update(_Uuser);
                _CyclingContext.SaveChanges();
                return Model;



            }
            catch (Exception Ex)
            {
                throw Ex;
            }
        }
        #endregion

        #region Select User details using user ID
        public UserViewModel SelectUser(Guid UserID)
        {

            var User = (from u in _CyclingContext.UUser
                        where u.UserId == UserID
                        select new UserViewModel
                        {
                            UserId = u.UserId,
                            TimeStampModified = u.TimeStampModified,
                            Password = Crypto.DoDecrypt(u.Password),
                            Answer = u.Answer,
                            SecurityQuestion = u.SecurityQuestion,
                            Region = u.Region,
                            Surname = u.Surname,
                            NickName = u.NickName,
                            Nation = u.Nation,
                            Name = u.Name,
                            Gender = u.Gender,
                            Email = u.Email,
                            City = u.City,
                            ContactNo = u.ContactNo,
                            Locations = u.Locations,
                            CMetricFormatsName = (from M in _CyclingContext.CMetricFormats where M.MetricFormatId ==   u.CMetricFormatsId select M.Name).FirstOrDefault(),
                            UGroupName = (from G in _CyclingContext.UGroup where G.GroupId == u.UGroupId select G.GroupName).FirstOrDefault(),
                            UShopName =( from S in _CyclingContext.UShop where S.ShopId == u.UShopId select S.ShopName).FirstOrDefault(),
                            
                            UTeamName = (from T in _CyclingContext.UTeam where T.TeamId == u.UTeamId select T.TeamName).FirstOrDefault(),
                           
                            CAthleteTypeName = (from A in _CyclingContext.CAthleteType where A.AthleteTypeId == u.CAthleteTypeId select A.Name).FirstOrDefault(),
                            
                            Zipcode = u.Zipcode
                        }) .FirstOrDefault();
            return User;
        }
        #endregion

        #region Select User details using user EmailID
        public UserViewModel SelectUserByEmail(string Email)
        {

            var User = (from u in _CyclingContext.UUser
                        where u.Email == Email
                        select new UserViewModel
                        {
                            UserId = u.UserId,
                            TimeStampModified = u.TimeStampModified,
                            Password = Crypto.DoDecrypt(u.Password),
                            Answer = u.Answer,
                            SecurityQuestion = u.SecurityQuestion,
                            Region = u.Region,
                            Surname = u.Surname,
                            NickName = u.NickName,
                            Nation = u.Nation,
                            Name = u.Name,
                            Gender = u.Gender,
                            Email = u.Email,
                            City = u.City,
                            ContactNo = u.ContactNo,
                            Locations = u.Locations,
                            CMetricFormatsName = (from M in _CyclingContext.CMetricFormats where M.MetricFormatId == u.CMetricFormatsId select M.Name).FirstOrDefault(),
                            UGroupName = (from G in _CyclingContext.UGroup where G.GroupId == u.UGroupId select G.GroupName).FirstOrDefault(),
                            UShopName = (from S in _CyclingContext.UShop where S.ShopId == u.UShopId select S.ShopName).FirstOrDefault(),

                            UTeamName = (from T in _CyclingContext.UTeam where T.TeamId == u.UTeamId select T.TeamName).FirstOrDefault(),

                            CAthleteTypeName = (from A in _CyclingContext.CAthleteType where A.AthleteTypeId == u.CAthleteTypeId select A.Name).FirstOrDefault(),

                            Zipcode = u.Zipcode
                        }).FirstOrDefault();
            return User;
        }
        #endregion

        #region Attachment update/Insert
        public List<AttachmentSnapshot> AttachmentUpdate(List<AttachmentSnapshot> Model)
        {
            List<AttachmentSnapshot> attachmentSnapshots = null;
            var User = (from u in _CyclingContext.UUser
                        where u.UserId == Model[0].UserID
                        select u).FirstOrDefault();

            if (User != null)
            { 
                // used for Attachment insert into the  uuserfiles table
                /*Certificate = 1,
                DeadLineCertificate = 2,
                TetanusProphylctis = 3*/

                if (Model.Count > 0)
                {
                    Guid FileID = Guid.Empty;
                    UUserFiles _UserFiles = null;
                    if (Model[0].FileByte != null)
                    {
                        FileID = (from f in _CyclingContext.UUserFiles where f.UserId == Model[0].UserID select f.FileId).FirstOrDefault();
                        _UserFiles = new UUserFiles();

                        _UserFiles.UserId = Model[0].UserID ?? Guid.Empty;
                        for (int i = 0; i < Model.Count; i++)
                        {
                            switch (Model[i].Category)
                            {
                                case "1":
                                    _UserFiles.Certificate = Convert.FromBase64String(Model[i].FileByte);
                                    _UserFiles.CertificateName = Model[i].FileName;
                                    break;
                                case "2":
                                    _UserFiles.DeadLineCertificate = Convert.FromBase64String(Model[i].FileByte);
                                    _UserFiles.DeadLineCertificateName = Model[i].FileName;
                                    break;
                                case "3":
                                    _UserFiles.TetanusProphylctis = Convert.FromBase64String(Model[i].FileByte);
                                    _UserFiles.TetanusProphylctisName = Model[i].FileName;
                                    break;

                            }
                        }
                    }

                    if (FileID == null || FileID == Guid.Empty)
                    {
                        _UserFiles.FileId = Guid.NewGuid();
                        _UserFiles.TimeStampCreated = DateTime.UtcNow;
                        _CyclingContext.UUserFiles.Add(_UserFiles);
                    }
                    else
                    {
                        _UserFiles.FileId = FileID;
                        _UserFiles.TimeStampModified = DateTime.UtcNow;
                        _CyclingContext.UUserFiles.Update(_UserFiles);
                    }

                    _CyclingContext.SaveChanges();

                }
                attachmentSnapshots = Model;
            }
            return attachmentSnapshots;
        }
        #endregion

        #region Email ID Duplication validation
        public bool EmailAleadyExists(string EmailID)
        {
            bool isValid = true;
            var user = (from u in _CyclingContext.UUser where u.Email == EmailID.Trim() select u).FirstOrDefault();
            isValid = user == null ? false : true;
            return isValid;

        }

        #endregion

        #region Select attachment using User ID and category

        public FileViewModel SelectAttachment(Guid UserID,FileCategory type)
        {
            FileViewModel _FileViewModel =null;
            
            var File = (from A in _CyclingContext.UUserFiles where A.UserId == UserID select A).FirstOrDefault();

            if(File != null)
            {
                switch (type)
                {
                    case FileCategory.Certificate:
                        _FileViewModel.FileByte = File.Certificate;
                        _FileViewModel.FileName = File.CertificateName;
                        break;

                    case FileCategory.DeadLineCertificate:
                        _FileViewModel.FileByte = File.DeadLineCertificate;
                        _FileViewModel.FileName = File.DeadLineCertificateName;
                        break;

                    case FileCategory.TetanusProphylctis:
                        _FileViewModel.FileByte = File.TetanusProphylctis;
                        _FileViewModel.FileName = File.TetanusProphylctisName;
                        break;

                }
            }
            return _FileViewModel;
        }
        #endregion
    }



}
