﻿using Cycling.Model.DbContexts;
using Cycling.Model.Model.ViewModels;
using Cycling.Repository.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cycling.Repository.Repository
{
   public class CodedRepository: ICodedRepository
    {
        private readonly CyclingContext _CyclingDbContext;
       public CodedRepository(CyclingContext _CyclingDbContext)
        {
            this._CyclingDbContext = _CyclingDbContext;
        }

        #region Select Group Details for Drop Down
        public List<CodedViewModel> SelectGroup()
        {
            List<CodedViewModel> Coded = (from UG in _CyclingDbContext.UGroup
                                          select new CodedViewModel
                                          {
                                              CodeID = UG.GroupId,
                                              CodeValue= UG.GroupName
                                          }).ToList();

            return Coded;
        }
        #endregion

        #region Select Shop Details for Drop Down
        public List<CodedViewModel> SelectShop()
        {
            List<CodedViewModel> Coded = (from S in _CyclingDbContext.UShop
                                          select new CodedViewModel
                                          {
                                              CodeID = S.ShopId,
                                              CodeValue = S.ShopName
                                          }).ToList();

            return Coded;
        }
        #endregion

        #region Select Team Details for Drop Down
        public List<CodedViewModel> SelectTeam()
        {
            List<CodedViewModel> Coded = (from T in _CyclingDbContext.UTeam
                                          select new CodedViewModel
                                          {
                                              CodeID = T.TeamId,
                                              CodeValue = T.TeamName
                                          }).ToList();

            return Coded;

        }
        #endregion

        #region Select CAthleteType Details for Drop Down
        public List<CodedViewModel> SelectCAthleteType()
        {
            List<CodedViewModel> Coded = (from C in _CyclingDbContext.CAthleteType where C.IsActive.Equals(true)
                                          select new CodedViewModel
                                          {
                                              CodeID = C.AthleteTypeId,
                                              CodeValue = C.Name
                                          }).ToList();

            return Coded;
        }
        #endregion

        #region Select CMetricFormats Details for Drop Down
        public List<CodedViewModel> SelectCMetricFormats()
        {
            List<CodedViewModel> Coded = (from M in _CyclingDbContext.CMetricFormats
                                          where M.IsActive.Equals(true)
                                          select new CodedViewModel
                                          {
                                              CodeID = M.MetricFormatId,
                                              CodeValue = M.Name
                                          }).ToList();

            return Coded;
        }
        #endregion

        #region Select Security Question Details for Drop Down
        public List<CodedViewModel> SelectSecurityQuestion()
        {
            List<CodedViewModel> Coded = (from S in _CyclingDbContext.USecurityQuestions
                                          where S.IsActive.Equals(true)
                                          select new CodedViewModel
                                          {
                                              CodeID = S.SecurityID,
                                              CodeValue = S.QuestionName
                                          }).ToList();

            return Coded;
        }
        #endregion
    }
}
