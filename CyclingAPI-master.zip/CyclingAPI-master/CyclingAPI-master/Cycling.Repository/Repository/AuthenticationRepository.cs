﻿using Cycling.Model.DbContexts;
using Cycling.Model.Model.Snapshot;
using Cycling.Model.Model.ViewModels;
using Cycling.Repository.Interfaces;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Cycling.Global;
using Cycling.Model.Models;

namespace Cycling.Repository.Repository
{
    public class AuthenticationRepository : IAuthenticationRepository
    {
        private readonly CyclingContext _CyclingContext;
        public AuthenticationRepository(CyclingContext _CyclingContext)
        {
            this._CyclingContext = _CyclingContext;
        }
        #region SingIn 
        public AuthViewModel SignIn(AuthSnapshot Model)
        {
            AuthViewModel _AuthViewModel = new AuthViewModel();
            UUser User = null;
            if (!string.IsNullOrEmpty(Model.Password.Trim()) && !string.IsNullOrEmpty(Model.Email.Trim()))
            {
                User = _CyclingContext.UUser.Where(x => x.Email != null && x.Email.ToLower() == Model.Email.ToLower()
                && !string.IsNullOrEmpty(x.Password) && Crypto.DoEncrypt(Model.Password) == x.Password).FirstOrDefault();

            }
            if (User != null)
            {
                _AuthViewModel.IsAuthenticationSuccess = true;
                _AuthViewModel.UserId = User.UserId;
            }
            else
            {
                _AuthViewModel.IsAuthenticationSuccess = false;
            }
            return _AuthViewModel;
        }
        #endregion

        #region Select User information 
        public AuthViewModel GetUserInfo(Guid UserID)
        {
            AuthViewModel _AuthViewModel = null;
            if (UserID != Guid.Empty)
            {
                _AuthViewModel = (from user in _CyclingContext.UUser
                                  where user.UserId == UserID
                                  select new AuthViewModel
                                  {
                                      UserId = user.UserId,
                                      Name = user.Name,
                                      Email = user.Email,
                                      Surname = user.Surname,
                                      Gender = user.Gender,
                                      IsAuthenticationSuccess = true,
                                      Token = ""
                                  }).FirstOrDefault();
            }
            return _AuthViewModel;
        }
        #endregion

        #region Forgot Password 
        public ForgotViewModel ForgotPassword(string EmailID)
        {
            ForgotViewModel _ForgotViewModel = (from user in _CyclingContext.UUser.Where(x => x.Email == EmailID)
                                                select new ForgotViewModel
                                                {
                                                    SecurityQuestion = user.SecurityQuestion,
                                                    Email = user.Email,
                                                    Answer = user.Answer,
                                                    UserId= user.UserId,
                                                    OTPUserID = user.OTPUserID
                                                }).FirstOrDefault();
            return _ForgotViewModel;

        }
        #endregion
        #region Forgot Password 
        public Dictionary<string,string> SelectOTPuserID(string MobileNo)
        {
            Dictionary<string, string> dictionary = null;
             var User = (from user in _CyclingContext.UUser.Where(x => x.ContactNo == MobileNo.Trim())select user).FirstOrDefault();
                   
            
            if(User != null)
            {
                dictionary = new Dictionary<string, string>
                        {
                            { "EmailID", User.Email },
                            { "OTPUserID", User.OTPUserID.ToString() },


                        };
            }
            return dictionary;
           

        }
        #endregion

     
    }
}
