﻿using Cycling.Model.DbContexts;
using Cycling.Model.Model.ViewModels;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Cycling.Repository.Interfaces;

namespace Cycling.Repository.Repository
{
    public class StatisticsRepository : IStatisticsRepository
    {
        private readonly CyclingContext _CyclingContect;
        public StatisticsRepository(CyclingContext _CyclingContect)
        {
            this._CyclingContect = _CyclingContect;
        }

        #region  Select list of Telemetary Data 
        public List<RaceDataViewModel> SelectRacedata(Guid UserID)
        {
            var RaceData = _CyclingContect.URacedata.Where(x => x.UserID == UserID).Select(Row => new RaceDataViewModel
            {
                Cadence = Row.Cadence,
                HeartRate = Row.HeartRate,
                Speed = Row.Speed,
                Time = Row.Time,
                TargetCadence = Row.TargetCadence,
                Distance = Row.Distance,
                Power = Row.Power

            }).ToList();
            return RaceData;
        }

        /// <summary>
        /// Fetch heart rate for each 500m distance
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<AverageHeartRateViewModel> AverageHearRateByDistance(Guid userId)
        {
            return _CyclingContect.URacedata.Where(u => u.UserID == userId).GroupBy(g => Math.Ceiling(g.Distance.Value * 2) / 2).Select(
                s => new AverageHeartRateViewModel
                {
                    Average = s.Average(p => p.HeartRate).Value,
                    Distance = s.Key
                })
                .ToList();
        }

        public double? AverageHeartRate(Guid userId)
        {
            return _CyclingContect.URacedata.Average(a => a.HeartRate);
        }

        public double? MaxHeartRate(Guid userId)
        {
            return _CyclingContect.URacedata.Max(a => a.HeartRate);
        }

        public double? MinHeartRate(Guid userId)
        {
            return _CyclingContect.URacedata.Min(a => a.HeartRate);
        }

        #endregion
    }
}
