﻿using System;

namespace Cycling.Repository
{
    public class Class1
    {
    }
}
