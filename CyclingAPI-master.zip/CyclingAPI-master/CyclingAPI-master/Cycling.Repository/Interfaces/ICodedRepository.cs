﻿using Cycling.Model.Model.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Repository.Interfaces
{
    public interface ICodedRepository
    {
        List<CodedViewModel> SelectGroup();

        List<CodedViewModel> SelectShop();

        List<CodedViewModel> SelectTeam();
        List<CodedViewModel> SelectCAthleteType();
        List<CodedViewModel> SelectCMetricFormats();
        List<CodedViewModel> SelectSecurityQuestion();
 
    }
}
