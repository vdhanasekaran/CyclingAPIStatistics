﻿using Cycling.Model.Model.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Repository.Interfaces
{
    public interface IStatisticsRepository
    {
        List<RaceDataViewModel> SelectRacedata(Guid UserID);

        List<AverageHeartRateViewModel> AverageHearRateByDistance(Guid userId);

        double? AverageHeartRate(Guid userId);

        double? MaxHeartRate(Guid userId);

        double? MinHeartRate(Guid userId);
    }
}
