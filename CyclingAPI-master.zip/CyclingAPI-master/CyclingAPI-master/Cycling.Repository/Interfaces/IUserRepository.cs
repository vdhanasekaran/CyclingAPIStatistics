﻿using Cycling.Model.Model.Snapshot;
using Cycling.Model.Model.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;
using static Cycling.Global.CommonEnum;

namespace Cycling.Repository.Interfaces
{
    public interface IUserRepository
    {
        UserSnapshot SignUp(UserSnapshot Model);
        UserSnapshot UserUpdate(UserSnapshot Model);
        UserViewModel SelectUser(Guid UserID);
        bool EmailAleadyExists(string EmailID);
        FileViewModel SelectAttachment(Guid UserID, FileCategory type);
        UserViewModel SelectUserByEmail(string Email);
    }
}
