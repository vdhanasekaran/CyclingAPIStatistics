﻿using Cycling.Model.Model.Snapshot;
using Cycling.Model.Model.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cycling.Repository.Interfaces
{
    public interface IAuthenticationRepository
    {
        AuthViewModel SignIn(AuthSnapshot Model);
        AuthViewModel GetUserInfo(Guid Model);
        ForgotViewModel ForgotPassword(string EmailID);
        Dictionary<string, string> SelectOTPuserID(string MobileNo);
        
    }
}
